# Aura — projet iOS (SwiftUI, iOS 16+)

## Générer le projet Xcode
    brew install xcodegen
    xcodegen generate        # lit project.yml → Aura.xcodeproj
    open Aura.xcodeproj

## IPA non signée (pour ksign / TrollStore / AltStore)
    xcodebuild -project Aura.xcodeproj -scheme Aura -configuration Release \
      -sdk iphoneos -derivedDataPath build CODE_SIGNING_ALLOWED=NO
    mkdir Payload && cp -R build/Build/Products/Release-iphoneos/Aura.app Payload/
    zip -r Aura.ipa Payload

Le widget est embarqué dans l'IPA (PlugIns/AuraWidget.appex). Le signeur doit le signer aussi.
Si ta méthode ne gère pas les App Groups, l'app fonctionne quand même ; seul le widget n'aura pas ses données.

## Format JSON d'une source de catalogue
    [ { "title": "Titre", "artist": "Artiste", "album": "Album", "genre": "Rock",
        "duration": 215, "cover": "https://…/cover.jpg", "url": "https://…/titre.mp3", "popularity": 42 } ]
Seul « url » est obligatoire. Les URL relatives sont résolues par rapport à l'URL de la source.
